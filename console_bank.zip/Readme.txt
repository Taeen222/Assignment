command to run bank.cpp:

gcc bank.cpp -o prog
./prog

command to run bank_balance_decode.c

gcc bank_balance_decode.c -o prog1
./prog1
